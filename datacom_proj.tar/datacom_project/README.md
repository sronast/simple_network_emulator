Project 2
## Start the Bridge
`python3 bridge.py lan-name number_of_ports`

## Input format to send message from one station to another
destination_name;message

# Input format for executing commands for printing info.
Routing table: print;rt
DNS table: print;dns
ARP table: print;arp