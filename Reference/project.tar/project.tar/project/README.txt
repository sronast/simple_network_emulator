1. ether.h: data structures for Ethernet
2. ip.h: data structures for IP and ARP
3. station.c
         main.c: template for implementing stations/routers
4. bridge.c
	 main.c: template for implementing bridges         
